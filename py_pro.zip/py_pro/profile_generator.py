

def get_user_data(name, age=25, **kwargs):
    """
    Gathers user information into a structured dictionary.
    """
    profile = {"name": name, "age": age}
    profile.update(kwargs)
    return profile

def format_profile(data, *args, format_type="detailed"):
    """
    Formats the user profile data into a readable string using f-strings.
    """
    name = data.get("name").title()
    age = data.get("age")
    hobbies_str = ", ".join(args) if args else "None listed"

    if format_type == "simple":
        return f"{name} ({age}) - Hobbies: {hobbies_str}"
    
    # Detailed format building
    res = [
        f"\n--- USER PROFILE: {name.upper()} ---",
        f"Age: {age}",
        f"Hobbies: {hobbies_str}"
    ]
    
    # Add extra metadata collected via kwargs
    for key, value in data.items():
        if key not in ["name", "age"]:
            res.append(f"{key.replace('_', ' ').title()}: {value}")
            
    res.append("-" * 30)
    return "\n".join(res)

def save_profile(profile_text, filename="profiles.txt"):
    """
    Appends the formatted profile to a file with error handling.
    """
    try:
        with open(filename, "a") as f:
            f.write(profile_text + "\n")
    except IOError as e:
        print(f"Critial Error: Could not write to {filename}. {e}")

def main():
    """
    Interactive main function to collect, display, and save user profiles.
    """
    profiles_list = []
    print("--- Interactive Profile Generator ---")

    while True:
        # Core data collection
        name = input("\nEnter name (or type 'quit' to finish): ")
        if name.lower() == 'quit':
            break
            
        try:
            age_input = input("Enter age (default 25): ")
            age = int(age_input) if age_input.strip() else 25
        except ValueError:
            print("Invalid age. Using default of 25.")
            age = 25

        # Collecting flexible data via kwargs
        job = input("Enter occupation: ")
        city = input("Enter city: ")
        
        # Collecting variable hobbies via *args
        hobbies_input = input("Enter hobbies separated by commas: ")
        hobbies = [h.strip() for h in hobbies_input.split(",")] if hobbies_input else []

        # Process data
        user_data = get_user_data(name, age=age, occupation=job, city=city)
        formatted = format_profile(user_data, *hobbies)
        
        # Store and save
        profiles_list.append(user_data)
        print(formatted)
        save_profile(formatted)
        print("Profile saved to profiles.txt")

    # Summary Statistics
    if profiles_list:
        total = len(profiles_list)
        avg_age = sum(u['age'] for u in profiles_list) / total
        print(f"\nSummary: {total} profiles created. Average age: {avg_age:.1f}")
    else:
        print("\nNo profiles were created.")

if __name__ == "__main__":
    main()